// LeetCode 232: Implement Queue using Stacks
// Two stacks make the queue work in FIFO order.

class MyQueue {
private:
    stack<int> inputStack;
    stack<int> outputStack;

    void moveItems() {
        // Move items only when outputStack is empty.
        if (outputStack.empty()) {
            while (!inputStack.empty()) {
                outputStack.push(inputStack.top());
                inputStack.pop();
            }
        }
    }

public:
    MyQueue() {
    }

    void push(int x) {
        inputStack.push(x);
    }

    int pop() {
        moveItems();
        int value = outputStack.top();
        outputStack.pop();
        return value;
    }

    int peek() {
        moveItems();
        return outputStack.top();
    }

    bool empty() {
        return inputStack.empty() && outputStack.empty();
    }
};

// Amortized time: O(1) per operation | Extra space: O(n)
