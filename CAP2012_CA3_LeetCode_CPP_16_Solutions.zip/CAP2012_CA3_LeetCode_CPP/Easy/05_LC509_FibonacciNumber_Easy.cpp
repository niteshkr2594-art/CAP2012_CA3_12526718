// LeetCode 509: Fibonacci Number
// Recursive definition: F(n) = F(n-1) + F(n-2).

class Solution {
public:
    int fib(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }

        return fib(n - 1) + fib(n - 2);
    }
};

// Time: O(2^n) | Recursion stack: O(n)
// This direct recursive version follows the recursion topic in the assignment.
