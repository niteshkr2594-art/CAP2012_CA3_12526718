// LeetCode 27: Remove Element
// Copy only values that are not equal to val.

class Solution {
public:
    int removeElement(vector<int>& nums, int val) {
        int position = 0;

        for (int i = 0; i < nums.size(); i++) {
            if (nums[i] != val) {
                nums[position] = nums[i];
                position++;
            }
        }

        return position;
    }
};

// Time: O(n) | Extra space: O(1)
