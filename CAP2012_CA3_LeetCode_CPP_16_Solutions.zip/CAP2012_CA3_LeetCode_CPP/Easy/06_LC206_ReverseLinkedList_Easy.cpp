// LeetCode 206: Reverse Linked List
// ListNode is provided by LeetCode.

class Solution {
public:
    ListNode* reverseList(ListNode* head) {
        ListNode* previous = nullptr;
        ListNode* current = head;

        while (current != nullptr) {
            ListNode* nextNode = current->next; // Save the next node
            current->next = previous;           // Reverse the link
            previous = current;
            current = nextNode;
        }

        return previous; // New head of the reversed list
    }
};

// Time: O(n) | Extra space: O(1)
