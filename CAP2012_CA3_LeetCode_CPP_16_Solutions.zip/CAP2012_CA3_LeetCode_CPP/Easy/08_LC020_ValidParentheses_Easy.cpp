// LeetCode 20: Valid Parentheses
// A stack stores opening brackets until their matching closing bracket appears.

class Solution {
public:
    bool isValid(string s) {
        stack<char> brackets;

        for (char ch : s) {
            if (ch == '(' || ch == '[' || ch == '{') {
                brackets.push(ch);
            } else {
                if (brackets.empty()) {
                    return false;
                }

                char top = brackets.top();
                brackets.pop();

                if (ch == ')' && top != '(') return false;
                if (ch == ']' && top != '[') return false;
                if (ch == '}' && top != '{') return false;
            }
        }

        return brackets.empty();
    }
};

// Time: O(n) | Extra space: O(n)
