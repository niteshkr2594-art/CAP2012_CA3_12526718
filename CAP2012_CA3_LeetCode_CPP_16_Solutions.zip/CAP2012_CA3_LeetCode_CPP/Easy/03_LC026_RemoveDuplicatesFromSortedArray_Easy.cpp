// LeetCode 26: Remove Duplicates from Sorted Array
// Keep one copy of each value in the beginning of the array.

class Solution {
public:
    int removeDuplicates(vector<int>& nums) {
        if (nums.empty()) {
            return 0;
        }

        int position = 1; // Where the next unique value should be placed

        for (int i = 1; i < nums.size(); i++) {
            if (nums[i] != nums[position - 1]) {
                nums[position] = nums[i];
                position++;
            }
        }

        return position; // New length of the array
    }
};

// Time: O(n) | Extra space: O(1)
