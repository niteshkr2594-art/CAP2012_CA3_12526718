// LeetCode 1281: Subtract the Product and Sum of Digits of an Integer

class Solution {
public:
    int subtractProductAndSum(int n) {
        int product = 1;
        int sum = 0;

        while (n > 0) {
            int digit = n % 10;   // Get the last digit
            product = product * digit;
            sum = sum + digit;
            n = n / 10;           // Remove the last digit
        }

        return product - sum;
    }
};

// Time: O(number of digits) | Extra space: O(1)
