// LeetCode 23: Merge k Sorted Lists
// A min-heap always gives the smallest currently available node.
// ListNode is provided by LeetCode.

class Solution {
public:
    ListNode* mergeKLists(vector<ListNode*>& lists) {
        // Compare nodes by their values so the smallest is on top.
        auto compare = [](ListNode* a, ListNode* b) {
            return a->val > b->val;
        };

        priority_queue<ListNode*, vector<ListNode*>, decltype(compare)> minHeap(compare);

        // Put the first node of every non-empty list into the heap.
        for (ListNode* node : lists) {
            if (node != nullptr) {
                minHeap.push(node);
            }
        }

        ListNode dummy(0);
        ListNode* tail = &dummy;

        while (!minHeap.empty()) {
            ListNode* smallest = minHeap.top();
            minHeap.pop();

            tail->next = smallest;
            tail = tail->next;

            // Add the next node from the same list.
            if (smallest->next != nullptr) {
                minHeap.push(smallest->next);
            }
        }

        tail->next = nullptr;
        return dummy.next;
    }
};

// Time: O(N log k), N = total nodes, k = number of lists
// Extra space: O(k) for the heap
