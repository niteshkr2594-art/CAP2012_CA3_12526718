// LeetCode 32: Longest Valid Parentheses
// Store indexes in a stack. The bottom index acts as a boundary.

class Solution {
public:
    int longestValidParentheses(string s) {
        stack<int> indexes;
        indexes.push(-1);

        int longest = 0;

        for (int i = 0; i < s.size(); i++) {
            if (s[i] == '(') {
                indexes.push(i);
            } else {
                indexes.pop();

                if (indexes.empty()) {
                    // This closing bracket becomes the new boundary.
                    indexes.push(i);
                } else {
                    int currentLength = i - indexes.top();
                    longest = max(longest, currentLength);
                }
            }
        }

        return longest;
    }
};

// Time: O(n) | Extra space: O(n)
