// LeetCode 92: Reverse Linked List II
// Reverse the nodes from position left to position right.
// ListNode is provided by LeetCode.

class Solution {
public:
    ListNode* reverseBetween(ListNode* head, int left, int right) {
        if (head == nullptr || left == right) {
            return head;
        }

        ListNode dummy(0);
        dummy.next = head;
        ListNode* before = &dummy;

        // Move before to the node just before position left.
        for (int i = 1; i < left; i++) {
            before = before->next;
        }

        ListNode* current = before->next;

        // Repeatedly take the next node and move it to the front
        // of the section being reversed.
        for (int i = 0; i < right - left; i++) {
            ListNode* nodeToMove = current->next;
            current->next = nodeToMove->next;
            nodeToMove->next = before->next;
            before->next = nodeToMove;
        }

        return dummy.next;
    }
};

// Time: O(n) | Extra space: O(1)
