// LeetCode 622: Design Circular Queue
// Use an array with front, rear and count.

class MyCircularQueue {
private:
    vector<int> data;
    int capacity;
    int frontIndex;
    int rearIndex;
    int count;

public:
    MyCircularQueue(int k) {
        capacity = k;
        data.resize(k);
        frontIndex = 0;
        rearIndex = -1;
        count = 0;
    }

    bool enQueue(int value) {
        if (isFull()) {
            return false;
        }

        rearIndex = (rearIndex + 1) % capacity;
        data[rearIndex] = value;
        count++;
        return true;
    }

    bool deQueue() {
        if (isEmpty()) {
            return false;
        }

        frontIndex = (frontIndex + 1) % capacity;
        count--;
        return true;
    }

    int Front() {
        if (isEmpty()) return -1;
        return data[frontIndex];
    }

    int Rear() {
        if (isEmpty()) return -1;
        return data[rearIndex];
    }

    bool isEmpty() {
        return count == 0;
    }

    bool isFull() {
        return count == capacity;
    }
};

// Time: O(1) for each operation | Extra space: O(k)
